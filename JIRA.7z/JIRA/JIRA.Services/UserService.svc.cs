﻿using DataAccessLayer;
using JIRA.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using JIRA.Services.Interfaces;
using System.ServiceModel.Activation;

namespace JIRA.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "UserService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select UserService.svc or UserService.svc.cs at the Solution Explorer and start debugging.
    [AspNetCompatibilityRequirements(
        RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class UserService : IUserService
    {
        private IConnectionFactory connectionFactory;

        public IList<User> GetUsers()
        {
            connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var userRep = new UserRepository(context);

            return userRep.GetUsers();
        }

        public User RegisterUser(User user)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var userRep = new UserRepository(context);

            return userRep.CreateUser(user);
        }


        public User Login(string id, string password)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var userRep = new UserRepository(context);

            return userRep.LoginUser(id,password);
        }

        public bool UserNameExists(string username,string email)
        {
            connectionFactory = ConnectionHelper.GetConnection();

            var context = new DbContext(connectionFactory);

            var userRep = new UserRepository(context);

            var user = userRep.GetUserByUsernameOrEmail(username,email);
            return !(user != null && user.UserID > 0);

        }
    }
}
