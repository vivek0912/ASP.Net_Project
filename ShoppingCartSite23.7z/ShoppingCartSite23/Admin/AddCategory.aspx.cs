﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;

public partial class Admin_AddCategory : System.Web.UI.Page
{
	SqlConnection cn = null;
	SqlCommand cmd = null;
	SqlDataAdapter da = null;
	DataSet ds = null;
	string filename;
	string filepath;

	string strCommand = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
		txtCategoryName.Focus();
	
 
    }
	void clearText()
	{
		txtCategoryName.Text = string.Empty;
		txtCatDescription.Text = string.Empty; 
		txtCatType.Text = string.Empty;
		FileCatImage = new FileUpload();
	}
	protected void btnCatAdd_Click(object sender, EventArgs e)
	{
		try
		{
			if(FileCatImage.HasFile)
			{

				filepath = @"~\Images\CategoryImage\"+ FileCatImage.FileName;
				FileCatImage.PostedFile.SaveAs(Server.MapPath(filepath));
			   
				
			}
		}
		catch(FileNotFoundException ex1)
		{
			lblCatStatus.Text = "<b style='color:red'>" + ex1.Message + "</b>";
		}
		catch(FileLoadException ex2)
		{
			lblCatStatus.Text = "<b style='color:red'>" + ex2.Message + "</b>";
		}
		cn = new SqlConnection(DatabaseConn.GetConnections());
		try
		{
			strCommand = "sp_InsertCategories";
			cmd = new SqlCommand(strCommand, cn);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.AddWithValue("@CategoryName", txtCategoryName.Text.Trim());
			cmd.Parameters.AddWithValue("@CategoryDesc", txtCatDescription.Text.Trim());
			cmd.Parameters.AddWithValue("@CategoryType", txtCatType.Text.Trim());
			cmd.Parameters.AddWithValue("@CategoryImage",filepath);

			da = new SqlDataAdapter(cmd);
			ds = new DataSet();
			da.Fill(ds,"tbl_ProductCategories");
			DataTable dt = ds.Tables["tbl_ProductCategories"];
			if(dt.Rows.Count>0)
			{
				lblCatStatus.Text = "<b style='color:green'>Categories Inserted Successfully</b>";
			}
			else
			{
				lblCatStatus.Text = "Insertion Failed!!!";
			}
			clearText();

		}
		catch(SqlException ex3)
		{
			lblCatStatus.Text ="<b style='color:red'>" + ex3.Message + "</b>";
		}
		catch(Exception ex4)
		{
			lblCatStatus.Text = "<b style='color:red'>" + ex4.Message + "</b>";
		}
		

	}
	protected void btnCancel_Click(object sender, EventArgs e)
	{
		clearText();
	}
}