﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;

public partial class Admin_AddProducts : System.Web.UI.Page
{
	SqlConnection cn = null;
	SqlCommand cmd = null;
	SqlDataAdapter da = null;
	DataSet ds = null;
	string filename="";
	string filepath="";

	string strcommand = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
		txtPname.Focus();
		if(IsPostBack)
		{
			cn = new SqlConnection(DatabaseConn.GetConnections());
			BindCategory();
		}
		
		
    }
	void BindCategory()
	{
		try
		{ 
		strcommand = "select category_name from tbl_ProductCategories";
		da = new SqlDataAdapter(strcommand, cn);
		ds=new DataSet();
		da.Fill(ds, "tbl_ProductCategories");

		ddlPCategory.DataSource = ds.Tables["tbl_ProductCategories"];
		ddlPCategory.DataTextField="Category_Name";
		ddlPCategory.DataValueField="Category_Name";
		ddlPCategory.DataBind();
		ddlPCategory.Items.Insert(0,new ListItem("Select","0"));
		}
		catch(SqlException ex1)
		{
			lblProdStatus.Text = "<b style='color:red'>" + ex1.Message + "</b>";
		}
		catch(Exception ex2)
		{
			lblProdStatus.Text = "<b style='color:red'>" + ex2.Message + "</b>";
		}
	}

	void ClearTexts()
	{
		txtCatId.Text = "";
		txtPname.Text = "";
		txtPBrand.Text = "";
		ddlPCategory.SelectedIndex = 0;
		txtPPrice.Text = "";
		txtPDescr.Text = "";
		fileProUpldImage = new FileUpload();
	}

	protected void btnAddProduct_Click(object sender, EventArgs e)
	{
		try
		{
			if(fileProUpldImage.HasFile)
			{
				filepath = @"~\Images\ProductImage\" + fileProUpldImage.FileName;
				fileProUpldImage.PostedFile.SaveAs(Server.MapPath(filepath));
			}
		}
		catch(FileNotFoundException ex1)
		{
			lblProdStatus.Text = "<b style='color:red'>" + ex1.Message + "</b>";
		}
		catch(FileLoadException ex2)
		{
			lblProdStatus.Text = "<b style='color:red'>" + ex2.Message + "</b>";
		}



		try
		{ 
		strcommand = "sp_InsertProduct";
		cmd = new SqlCommand(strcommand, cn);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.AddWithValue("@ProductName", txtPname.Text.Trim());
		cmd.Parameters.AddWithValue("@ProductBrand",txtPBrand.Text.Trim());
		cmd.Parameters.AddWithValue("@ProductCategory",txtPBrand.Text.Trim());
		cmd.Parameters.AddWithValue("@ProductPrice",txtPPrice.Text.Trim());
		cmd.Parameters.AddWithValue("@ProductDesc",txtPDescr.Text.Trim());
		cmd.Parameters.AddWithValue("@CategoryId",txtCatId.Text.Trim());
		cmd.Parameters.AddWithValue("@productImage", filepath);

		da = new SqlDataAdapter(cmd);
		ds = new DataSet();
		da.Fill(ds, "tbl_Product");
		DataTable dt = ds.Tables["tbl_Product"];
			if(dt.Rows.Count>0)
			{
				lblProdStatus.Text = "<b style='color:green'>Product Inserted Successfully</b>";
			}
			else
			{
				lblProdStatus.Text = "Inserttion failed!!!";
			}
			ClearTexts();
		}
		catch(SqlException ex1)
		{
			lblProdStatus.Text = "<b style='color:red'>" + ex1.Message + "</b>";
		}
		catch(Exception ex2)
		{
			lblProdStatus.Text = "<b style='color:red'>" + ex2.Message + "</b>";
		}
	}
	protected void btnAddReset_Click(object sender, EventArgs e)
	{
		ClearTexts();
	}
}