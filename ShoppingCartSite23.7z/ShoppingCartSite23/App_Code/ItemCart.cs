﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Collections;
using System.ComponentModel;

/// <summary>
/// Summary description for ItemCart
/// </summary>

   [Serializable]
public class ItemCart:DictionaryBase
{
	
	public Products this[string key]
	{
		get { return (Products)this.Dictionary[key]; }
		set { this.Dictionary[key] = value; }

	}
	public void AddCartItem(string key, Products objProducts)
	{
		this.Dictionary.Add(key, objProducts);
	}
	public bool Contains(string key)
	{
		return this.Dictionary.Contains(key);
	}
	public ICollection Keys
	{
		get { return this.Dictionary.Keys; }
	}
	public void Removeitem(string key)
	{
		this.Dictionary.Remove(key);

	}
	public void RemoveAll()
	{
		this.Dictionary.Clear();
	}
	public int ItemCount
	{
		get { return this.Dictionary.Count; }
	}
}