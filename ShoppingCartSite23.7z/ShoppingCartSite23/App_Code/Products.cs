﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Products
/// </summary>
public class Products
{
	public Products()
	{
		//
		// TODO: Add constructor logic here
		//
	}
	private int _productid;
	public int Product_Id
	{
		get
		{
			return _productid;
		}
		set
		{
			_productid = value;
		}
	}

	private string _productName;
		public string Product_Name
		{
			get
			{
				return _productName;
			}
			set
			{
				_productName=value;
			}
		}


	/// <summary>
	/// Property for ProductDescription
	/// </summary>
	private string _productdescription;
	public string Product_Description
	{
		get
		{
			return _productdescription;
		}
		set
		{
			_productdescription = value;
		}
	}

	/// <summary>
	/// Property for ProductImage
	/// </summary>
	private string _productimage;
	public string Product_Image
	{
		get
		{
			return _productimage;
		}
		set
		{
			_productimage = value;
		}
	}

	/// <summary>
	/// Property for ProductPrice
	/// </summary>
	private decimal _Price;
	public decimal Price
	{
		get
		{
			return _Price;
		}
		set
		{
			_Price = value;
		}
	}

	/// <summary>
	/// Property for CreatedDate
	/// </summary>


	/// <summary>
	/// Property for Quantity
	/// </summary>
	private int _quantity;
	public int Quantity
	{
		get
		{
			return _quantity;
		}
		set
		{
			_quantity = value;
		}
	}
	
	/// <summary>
	/// Property for Total
	/// </summary>
	public decimal Total
	{
		get { return (this.Quantity * this.Price); }
	}
}