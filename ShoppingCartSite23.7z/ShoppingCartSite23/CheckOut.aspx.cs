﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Collections;
using System.Data;
using System.Data.SqlClient;


public partial class CheckOut : System.Web.UI.Page
{
	SqlConnection cn = null;
	SqlCommand cmd = null;
	SqlDataAdapter da = null;
	
	string strCommand = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
		cn = new SqlConnection(DatabaseConn.GetConnections());
		 if(!Page.IsPostBack)
		 {
			 BindCheckOutGrid();
			 UserBillingInfo();
			
		 }
		
		//if (Session["image"] != null)
		//{
		//	imgCart.ImageUrl = Session["image"].ToString();
		//}
		//if (Session["price"] != null)
		//{
		//	priceCart.Text = Session["price"].ToString();
		//}
		
		
    }
	public void UserBillingInfo()
	{
		string Uid = Session["UserRegId"].ToString();
		try
		{
			strCommand = "select * from tbl_Registration where Reg_Id=" + Uid;
			cmd = new SqlCommand(strCommand, cn);
			da = new SqlDataAdapter(cmd);
			
			DataTable dt = new DataTable();
			da.Fill(dt);
		
		      
			if(dt.Rows.Count>0)
			{
				lblBillFname.Text = dt.Rows[0]["FirstName"].ToString();
				lblBillLname.Text = dt.Rows[0]["LastName"].ToString();
				lblBillAddress.Text=dt.Rows[0]["FAddress"].ToString();
				lblBillMonile.Text = dt.Rows[0]["Mobile"].ToString();
			}
		}
		catch(SqlException ex1)
		{
			Response.Write(ex1.Message);
		}
	}
	public void BindCheckOutGrid()
	{
		ItemCart objItemcart = ((ItemCart)Session["cart"]);
		List<Products> objProducts=new List<Products>();
		
		foreach(DictionaryEntry objDic in objItemcart)
		{
			objProducts.Add((Products)objDic.Value);
		}
		gridCheckOut.DataSource = objProducts;
		gridCheckOut.DataBind();
		
	}
	//protected void btncheckout_Click(object sender, ImageClickEventArgs e)
	//{
	//	Session["Amount"] = Session["price"].ToString();

	//	Response.Redirect("Paypal.aspx");
	//}
	protected void gridCheckOut_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if(e.Row.RowType== DataControlRowType.Footer)
		{
			decimal total = 0;
			if(Session["cart"]!=null)
			{ 
			    ItemCart objitemcart = ((ItemCart)Session["cart"]);
			    foreach(DictionaryEntry objDic in objitemcart)
				{
					Products objProducts=((Products)objDic.Value);
					total=total + objProducts.Total;
				}
				Session["TotalAmt"] = total.ToString();
				e.Row.Cells[2].Text="<b style='Font-Size:20px'>Total:"+total.ToString()+"</b>";
		
			}
		}
	}
	protected void imgBtnPaypal_Click(object sender, ImageClickEventArgs e)
	{
		Response.Redirect("~/PayPal.aspx");
	}
	protected void imgBtnAuthorizeNet_Click(object sender, ImageClickEventArgs e)
	{
        Response.Redirect("~/PaymentAuthorize.aspx");
	}
}