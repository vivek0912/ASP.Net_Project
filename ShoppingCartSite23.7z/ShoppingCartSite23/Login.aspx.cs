﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;

public partial class Login : System.Web.UI.Page
{
	SqlConnection cn = null;
	SqlCommand cmd = null;
	SqlDataAdapter da = null;
	//SqlDataReader dr = null;
	int cout;
	string username, password;

	string strCommand = string.Empty;
	protected void Page_Load(object sender, EventArgs e)
	{
		if (IsPostBack)
		{
			cn = new SqlConnection(DatabaseConn.GetConnections());
			
		}
		if (Session["userid"] != null)
		{
			Response.Redirect("~/Home.aspx");
		}
	}
	protected void imgBtnLogin_Click(object sender, ImageClickEventArgs e)
	{
		try
		{
			strCommand = "select * from tbl_Registration where UserId=@userid and Passwords=@password";
			cmd = new SqlCommand(strCommand, cn);
			cmd.Parameters.AddWithValue("@userid",txtAdminId.Text.Trim());
			cmd.Parameters.AddWithValue("@password",txtPassword.Text.Trim());
			da = new  SqlDataAdapter(cmd);

			DataTable dt = new DataTable();
			da.Fill(dt);
			if(dt.Rows.Count>0)
			{
				Session["UserRegId"] = dt.Rows[0]["Reg_Id"];
				//string UId = dt.Rows[0]["Reg_Id"].ToString();
			
				if(dt.Rows[0]["Roles"].ToString()=="admin")
				{
					Session["adminId"]=txtAdminId.Text;
					Response.Redirect("~/Admin/AdminHome.aspx");
				}
				if(dt.Rows[0]["Roles"].ToString()=="user")
				{
					Session["userId"] = txtAdminId.Text;
					Session["UserName"] = dt.Rows[0]["FirstName"];
					if (Session["cart"] != null)
					{
						Response.Redirect("~/ViewCart.aspx");
					}
					else
					{
					
						Response.Redirect("~/ProductHome.aspx");
					}
				}
			}
			else
			{
				lblLoginStatus.Text = "<b style='color:red'>your Credential are incorrect!!!</b>";
			}
			

		

			//while (dr.Read())
			//{
			//	if (dr[4].ToString().Equals(txtAdminId.Text) && dr[6].ToString().Equals(txtPassword.Text))
			//	{
			//		Response.Cookies["UName"].Value = txtAdminId.Text;
			//		Response.Cookies["Password"].Value = txtPassword.Text;
			//		Response.Cookies["role"].Value = dr[5].ToString();
			//		FormsAuthentication.RedirectFromLoginPage(txtAdminId.Text, false);

			//	}
			//	else
			//	{
			//		lblLoginStatus.Text = "<b style='color:red'>your Credential are incorrect!!!</b>";
			//	}
			//}

		}
		catch (SqlException ex1)
		{
			lblLoginStatus.Text = "<b style='color:red'>" + ex1.Message + "</b>";
		}
		catch (Exception ex2)
		{
			lblLoginStatus.Text = "<b style='color:red'>" + ex2.Message + "</b>";
		}
		//finally
		//{
		//	dr.Close();
		//	cn.Close();
			
		//}
	}

}