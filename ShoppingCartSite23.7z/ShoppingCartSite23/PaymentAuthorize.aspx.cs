﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Text;
using System.Collections;
using System.Net.Mail;
using System.IO;
using System.Net;


public partial class PaymentAuthorize : System.Web.UI.Page
{
	string expDate = string.Empty;
	string post_url;
	String post_string;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
	protected void btnMakePay_Click(object sender, EventArgs e)
	{
		expDate = ddlMonth.SelectedValue + ddlYear.SelectedValue;
		post_url = ConfigurationManager.AppSettings["AuthorizeSubmitUrl"];

		Hashtable post_Value = new Hashtable();
		post_Value.Add("x_login", ConfigurationManager.AppSettings["APILOGINKEY"]);
		post_Value.Add("x_tran_key", ConfigurationManager.AppSettings["APITRANSACTIONKEY"]);
		post_Value.Add("x_delim_data", "TRUE");
		post_Value.Add("x_delim_char", '|');
		post_Value.Add("x_relay_response", "FALSE");
		post_Value.Add("x_type", "AUTH_CAPTURE");
		post_Value.Add("x_method", "CC");
		post_Value.Add("x_card_num",txtCardNo.Text.Trim());
		post_Value.Add("x_exp_date", expDate.Trim());
		post_Value.Add("x_amount", Convert.ToDecimal(Session["TotalAmt"].ToString()));
		post_Value.Add("x_description", "Sample Transaction");
	
		foreach(DictionaryEntry objDic in post_Value)
		{
			post_string += objDic.Key + "=" + objDic.Value + "&";
		}
		post_string = post_string.TrimEnd('&');
		HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(post_url);
		objRequest.Method = "POST";
		objRequest.ContentLength = post_string.Length;
		objRequest.ContentType = "application/x-www-form-urlencoded";

		StreamWriter myWriter = null;
		myWriter = new StreamWriter(objRequest.GetRequestStream());
		myWriter.Write(post_string);
		myWriter.Close();

		string post_response;
		HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
		using (StreamReader responseStream = new StreamReader(objResponse.GetResponseStream()))
		{
			post_response = responseStream.ReadToEnd();
			responseStream.Close();
		}

	}
}