﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Net;
using System.IO;
using System.Collections;
using System.Web.SessionState;
using System.Web.Configuration;
using System.Xml;
using System.Globalization;
using System.Text;
using System.Data.SqlClient;
using System.Data;



public partial class PaymentSuccess : System.Web.UI.Page
{
	string authToken;
	string txToken;
	string query;
	string requestUriString;
    protected void Page_Load(object sender, EventArgs e)
    {
		if (!IsPostBack)
		{
			try
			{
				string Token = ConfigurationManager.AppSettings["PDTToken"];
				string tid = Request.QueryString.Get("tx");
				string query = "cmd=_notify-synch&tx=" + tid + "&at=" + Token;

				HttpWebRequest objrequest = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings["PayPalSubmitUrl"]);
				objrequest.Method = "POST";
				objrequest.ContentLength = query.Length;
				objrequest.ContentType = "application/x-www-form-urlencoded";
				StreamWriter mywriter = new StreamWriter(objrequest.GetRequestStream(), Encoding.ASCII);
				mywriter.Write(query);
				mywriter.Close();
				string strresponse = string.Empty;
				StreamReader myreader = new StreamReader(objrequest.GetResponse().GetResponseStream());
				strresponse = myreader.ReadToEnd();
				myreader.Close();
				
				
			}
			catch (Exception ee)
			{
				Response.Write( "Payment not processed due to " + ee.Message);

			}
		}
	}

	public PaymentSuccess()
       {
        base.Load += new EventHandler(Page_Load);
       }

}