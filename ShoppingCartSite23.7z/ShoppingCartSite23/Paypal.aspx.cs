﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class Paypal : System.Web.UI.Page
{
	protected string cmd;
	protected string business;
	protected string item_name;
	protected string amount;
	protected string currency_code;
	protected string no_shipping;
	protected string return_url;
	protected string rm;
	protected string URL;
	public Paypal()
	{
		base.Load+=new EventHandler(this.Page_Load);
		
		this.business = ConfigurationManager.AppSettings["BusinessEmail"];
		this.item_name = "Payments for Item";
		this.return_url=ConfigurationManager.AppSettings["ReturnUrl"];
		this.currency_code = ConfigurationManager.AppSettings["CurrencyCode"];

	}

    protected void Page_Load(object sender, EventArgs e)
    {
		if (String.Compare(ConfigurationManager.AppSettings["UseSandbox"].ToString(), "true", false) == 0)
		{
			this.URL = "https://www.sandbox.paypal.com/cgi-bin/webscr";
		}
		else
		{
			this.URL = "https://www.paypal.com/cgi-bin/webscr";
		}
		if (String.Compare(ConfigurationManager.AppSettings["SendToReturnURL"].ToString(), "true", false) == 0)
		{
			this.rm = "2";
		}
		else
		{
			this.rm = "1";
		}

		this.amount = this.Session["TotalAmt"].ToString();

    }
}