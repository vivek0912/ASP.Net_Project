﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;


public partial class Product_Nokia : System.Web.UI.Page
{
	SqlConnection cn = null;
	SqlDataAdapter da = null;
	DataSet ds = null;

	Products objproducts = new Products();
	ItemCart objitemcart = new ItemCart();

	string strSqlCommand = String.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
		cn = new SqlConnection(DatabaseConn.GetConnections());
		if (!Page.IsPostBack)
		{
			BindProduct();
		}

    }
	void BindProduct()
	{
		strSqlCommand = "Select * from tbl_Product where Product_Category='Nokia'";
		da = new SqlDataAdapter(strSqlCommand, cn);
		ds = new DataSet();
		da.Fill(ds, "tbl_Product");
		dataListNokia.DataSource = ds.Tables["tbl_Product"];
		dataListNokia.DataBind();
	}
	protected void btnAddToCart_Click(object sender, EventArgs e)
	{
		Response.Redirect("http://localhost:45212/Cart.aspx");
	}
	protected void lnkNkViewCart_Click(object sender, EventArgs e)
	{

	}
	protected void lnkNkBtnCheckout_Click(object sender, EventArgs e)
	{

	}
	protected void dataListNokia_ItemCommand(object source, DataListCommandEventArgs e)
	{
		if (e.CommandName == "AddCart")
		{
			//try
			//{
			System.Data.DataRowView drv = ((System.Data.DataRowView)e.Item.DataItem);

			Label lblCost = ((Label)e.Item.FindControl("lblPrice"));
			Products objProducts1 = new Products();
			HiddenField ProductName = ((HiddenField)e.Item.FindControl("hiddenName"));
			HiddenField ProductId = ((HiddenField)e.Item.FindControl("hiddenPid"));
			HiddenField price = ((HiddenField)e.Item.FindControl("hiddenPrice"));
			// Label hdnproductiamge = ((Label)e.Item.FindControl("lblproductimage"));
			HiddenField productImage = ((HiddenField)e.Item.FindControl("hiddenImage"));

			objProducts1.Quantity = 1;
			objProducts1.Product_Id = Convert.ToInt16(ProductId.Value.ToString());
			string cost = price.Value.ToString().Replace("$", "");
			objProducts1.Price = Convert.ToDecimal(cost);
			objProducts1.Product_Id = Convert.ToInt32(ProductId.Value.ToString());

			objProducts1.Product_Image = productImage.Value.ToString();
			if (Session["cart"] != null)
			{
				objitemcart = ((ItemCart)Session["cart"]);

				if (!objitemcart.Contains(objProducts1.Product_Id.ToString()))
				{
					objitemcart.AddCartItem(objProducts1.Product_Id.ToString(), objProducts1);

				}
				Session["cart"] = objitemcart;
			}
			else
			{
				objitemcart.AddCartItem(objProducts1.Product_Id.ToString(), objProducts1);
				Session["cart"] = objitemcart;
			}
			if (Session["cart"] != null)
			{
				ItemCart objcart = ((ItemCart)Session["cart"]);
				lblcart.Text = "";
				decimal total = 0;

				foreach (DictionaryEntry objde in objcart)
				{
					Products objprodcts = ((Products)objde.Value);
					total = total + objprodcts.Total;
				}
				lblcart.Text = "You have  " + objcart.Count + " items " + "Totaling  " + total.ToString("c");
				imgEmpty.ImageUrl = "~/images/shopping_cart_accept.png";
			}
			lnkNkBtnCheckout.Attributes.Remove("OnClick");

		}
	}
}