﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;

public partial class Sumsang_Samsung : System.Web.UI.Page
{
	SqlConnection cn = null;
	SqlDataAdapter da = null;
	DataSet ds = null;

	Products objproducts = new Products();
	ItemCart objitemcart = new ItemCart();

	string strSqlCommand = String.Empty;
	protected void Page_Load(object sender, EventArgs e)
	{
		cn = new SqlConnection(DatabaseConn.GetConnections());
		if (!Page.IsPostBack)
		{
			BindProduct();
			//if(Session["userid"]!=null)
			//{
			//	btnSamLogout.Enabled = true;
			//	lblUserid.Text = Session["userid"].ToString();
               
			//}
			//else
			//{
			//	btnSamLogout.Enabled = false;
			//	lblUserid.Text = "Welcome Guest";
			//}
		}
	}
	protected void lnkBtnImage1_Click(object sender, EventArgs e)
	{
		//if(chk1.Checked==true)
		//{
		//	lblcart.Text = "Item Added Into Cart";
		//	Session["image"] = image1.ImageUrl;
		//	Session["Price"] = lblPrice1.Text;
		//}
		//if(chk2.Checked==true)
		//{
		//	lblcart.Text = "Item Added Into Cart";
		//	Session["image"] = image2.ImageUrl;
		//	Session["Price"] = lblPrice2.Text;
		//}
		//if (chk3.Checked == true)
		//{
		//	lblcart.Text = "Item Added Into Cart";
		//	Session["image"] = image3.ImageUrl;
		//	Session["Price"] = lblPrice3.Text;
		//}
		//if (chk4.Checked == true)
		//{
		//	lblcart.Text = "Item Added Into Cart";
		//	Session["image"] = image4.ImageUrl;
		//	Session["Price"] = lblPrice4.Text;
		//}
	}

	protected void lnkship_Click(object sender, EventArgs e)
	{
		//Response.Redirect("~/CheckOut.aspx");
	}
	void BindProduct()
	{
		strSqlCommand = "Select * from tbl_Product where Product_category='Samsung'";
		da = new SqlDataAdapter(strSqlCommand, cn);
		ds = new DataSet();
		da.Fill(ds, "tbl_Product");
		dataListSamsung.DataSource = ds.Tables["tbl_Product"];
		dataListSamsung.DataBind();
	}
	protected void btnAddToCart_Click(object sender, EventArgs e)
	{


	}
	protected void dataListSamsung_ItemCommand(object source, DataListCommandEventArgs e)
	{
		#region 1
		//if (e.CommandName == "AddCart")
		//{
		//	try
		//	{
		//		DataRowView drv = ((DataRowView)e.Item.DataItem);
		//		// //ProductImage = ((HiddenField)e.Item.FindControl("ProductImage"));
		//		//string Pname = Convert.ToString(((Label)e.Item.FindControl("lblPname")));
		//		//string Price =Convert.ToString( ((Label)e.Item.FindControl("lblPrice")));
		//		Label pid = ((Label)e.Item.FindControl("lblPid"));
		//		Response.Redirect("../Cart.aspx?Pid=" + pid.Text);
		//	}
		//	catch (Exception ex)
		//	{
		//		Response.Write(ex.Message);
		//	}
		#endregion

		if (e.CommandName == "AddCart")
			{
				//try
				//{
					System.Data.DataRowView drv = ((System.Data.DataRowView)e.Item.DataItem);

					 Label lblCost= ((Label)e.Item.FindControl("lblPrice"));
					Products objProducts1 = new Products();
					HiddenField ProductName = ((HiddenField)e.Item.FindControl("hiddenName"));
					HiddenField ProductId = ((HiddenField)e.Item.FindControl("hiddenPid"));
					HiddenField price = ((HiddenField)e.Item.FindControl("hiddenPrice"));
				   // Label hdnproductiamge = ((Label)e.Item.FindControl("lblproductimage"));
					HiddenField productImage = ((HiddenField)e.Item.FindControl("hiddenImage"));

					objProducts1.Quantity = 1;
					objProducts1.Product_Id = Convert.ToInt16(ProductId.Value.ToString());
					string cost = price.Value.ToString().Replace("$", "");
					objProducts1.Price = Convert.ToDecimal(cost);
					objProducts1.Product_Id = Convert.ToInt32(ProductId.Value.ToString());
					objProducts1.Product_Name = ProductName.Value.ToString();

					objProducts1.Product_Image = productImage.Value.ToString();
					if (Session["cart"] != null)
					{
						objitemcart = ((ItemCart)Session["cart"]);

						if (!objitemcart.Contains(objProducts1.Product_Id.ToString()))
						{
							objitemcart.AddCartItem(objProducts1.Product_Id.ToString(), objProducts1);

						}
						Session["cart"] = objitemcart;
					}
					else
					{
						objitemcart.AddCartItem(objProducts1.Product_Id.ToString(), objProducts1);
						Session["cart"] = objitemcart;
					}
					if (Session["cart"] != null)
					{
						ItemCart objcart = ((ItemCart)Session["cart"]);
						lblcart.Text = "";
						decimal total = 0;

						foreach (DictionaryEntry objde in objcart)
						{
							Products objprodcts = ((Products)objde.Value);
							total = total + objprodcts.Total;
						}
						lblcart.Text = "You have  " + objcart.Count + " items " + "Total Amount " + total.ToString("c");
						imgEmpty.ImageUrl = "~/images/shopping_cart_accept.png";
					}
					lnkBtnCheckout.Attributes.Remove("OnClick");

			}


			//}

		

	}
	protected void lnkViewCart_Click(object sender, EventArgs e)
	{
		Response.Redirect("~/ViewCart.aspx");
	}
}

	
