﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Site : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if(!Page.IsPostBack)
		{
			if(Session["userid"]!=null)
			{
				btnLogout.Visible = true;
				lblWelcomeMsg.Text = "Welcome " + Session["UserName"].ToString();
			}
			else
				btnLogout.Visible = false; 

		}
    }
	protected void btnLogin_Click(object sender, EventArgs e)
	{

		Response.Redirect("Login.aspx");
	}
	protected void btnLogout_Click(object sender, EventArgs e)
	{

		if (Session["userid"] != null)
		{
			
			lblWelcomeMsg.Text = "Welcome Guest";
		
			Session["userid"] = null;
			//Session["cart"] = null;
			btnLogout.Visible = false;
			Response.Redirect("~/Home.aspx");
		}
		
			
	
	}
}
