﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class ViewCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
		if (!IsPostBack)
		{
			BindGridView();
		}
	

    }
	public void BindGridView()
	{
		ItemCart objcartitemcart = ((ItemCart)Session["cart"]);
		List<Products> objcproducts = new List<Products>();
		if (objcartitemcart != null)
		{
			foreach (DictionaryEntry objde in objcartitemcart)
			{
				objcproducts.Add((Products)objde.Value);
			}
		}
		gridViewCart.DataSource = objcproducts;
		gridViewCart.DataBind();
	}
	protected void gridViewCart_RowCommand(object sender, GridViewCommandEventArgs e)
	{

	}
	protected void gridViewCart_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if(e.Row.RowType==DataControlRowType.Footer)
		{
			//Label cost = ((Label)e.Row.FindControl("lblTotal"));
			decimal total = 0;
			if(Session["cart"]!=null)
			{
				ItemCart onjitemCart = ((ItemCart)Session["cart"]);
				foreach(DictionaryEntry objDic in onjitemCart)
				{
					Products objProducts = ((Products)objDic.Value);
					total = total + objProducts.Total;

				}
				e.Row.Cells[3].Text = total.ToString();
			
			  
			}
			
		}
	
	}
	protected void txtquantity_TextChanged(object sender, EventArgs e)
	{

	}
	protected void txtViewQuantity2_TextChanged(object sender, EventArgs e)
	{

	}


	protected void btnCheckOut_Click(object sender, EventArgs e)
	{
		if (Session["userid"] == null)
		{
			Response.Redirect("~/Login.aspx");
		}
		else
		{ 
		Response.Redirect("~/CheckOut.aspx");
		}
	}
	protected void btnEmptyCart_Click(object sender, EventArgs e)
	{

	}
}